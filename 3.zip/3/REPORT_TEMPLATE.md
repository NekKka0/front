# Отчёт ПЗ-3 (Postman)

## 1) Локальное API (3 запроса)
- GET /products (200)
- GET /products/1 (200 или 404)
- POST /products (201)

Вставь 3 скриншота ответов.

## 2) Внешнее API (5 запросов) — OpenWeatherMap
Endpoint: https://api.openweathermap.org/data/2.5/weather
Параметры: q, appid, units=metric, lang=ru

Вставь 5 скриншотов ответов.

## 3) Ссылка на репозиторий
(вставь ссылку)
