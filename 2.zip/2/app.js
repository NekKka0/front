const express = require("express");
const app = express();
const port = 3000;

app.use(express.json());

// Данные "в памяти"
let products = [
  { id: 1, name: "Хлеб", price: 50 },
  { id: 2, name: "Молоко", price: 90 },
  { id: 3, name: "Сыр", price: 250 },
];

app.get("/", (req, res) => {
  res.send("Products API работает");
});

// READ ALL
app.get("/products", (req, res) => {
  res.json(products);
});

// READ ONE
app.get("/products/:id", (req, res) => {
  const product = products.find((p) => p.id === Number(req.params.id));
  if (!product) return res.status(404).json({ message: "Товар не найден" });
  res.json(product);
});

// CREATE
app.post("/products", (req, res) => {
  const { name, price } = req.body;

  if (!name || price === undefined) {
    return res.status(400).json({ message: "Нужны поля name и price" });
  }
  if (typeof price !== "number" || price < 0) {
    return res.status(400).json({ message: "price должен быть числом >= 0" });
  }

  const newProduct = { id: Date.now(), name, price };
  products.push(newProduct);
  res.status(201).json(newProduct);
});

// UPDATE (частично)
app.patch("/products/:id", (req, res) => {
  const product = products.find((p) => p.id === Number(req.params.id));
  if (!product) return res.status(404).json({ message: "Товар не найден" });

  const { name, price } = req.body;

  if (name !== undefined) {
    if (!name) return res.status(400).json({ message: "name не может быть пустым" });
    product.name = name;
  }
  if (price !== undefined) {
    if (typeof price !== "number" || price < 0) {
      return res.status(400).json({ message: "price должен быть числом >= 0" });
    }
    product.price = price;
  }

  res.json(product);
});

// DELETE
app.delete("/products/:id", (req, res) => {
  const id = Number(req.params.id);
  const before = products.length;
  products = products.filter((p) => p.id !== id);

  if (products.length === before) {
    return res.status(404).json({ message: "Товар не найден" });
  }
  res.json({ message: "Ok" });
});

app.listen(port, () => {
  console.log(`Сервер запущен: http://localhost:${port}`);
});
