import React from "react";

export default function ProductItem({ product, onEdit, onDelete }) {
  return (
    <div className="card">
      {product.image ? <img className="img" src={product.image} alt={product.name} /> : null}

      <div className="card__body">
        <div className="meta">
          <span className="pill">{product.category}</span>
          <span className="id">#{product.id}</span>
        </div>

        <div className="name">{product.name}</div>
        <div className="desc">{product.description}</div>

        <div className="row">
          <div className="price">{product.price} ₽</div>
          <div className="stock">На складе: {product.stock}</div>
        </div>

        {product.rating != null ? <div className="rating">Рейтинг: {product.rating}</div> : null}

        <div className="actions">
          <button className="btn" onClick={() => onEdit(product)}>
            Редактировать
          </button>
          <button className="btn btn--danger" onClick={() => onDelete(product.id)}>
            Удалить
          </button>
        </div>
      </div>
    </div>
  );
}
