import React, { useEffect, useState } from "react";

export default function ProductModal({ open, mode, initialProduct, onClose, onSubmit }) {
  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [stock, setStock] = useState("");
  const [rating, setRating] = useState("");
  const [image, setImage] = useState("");

  useEffect(() => {
    if (!open) return;
    setName(initialProduct?.name ?? "");
    setCategory(initialProduct?.category ?? "");
    setDescription(initialProduct?.description ?? "");
    setPrice(initialProduct?.price != null ? String(initialProduct.price) : "");
    setStock(initialProduct?.stock != null ? String(initialProduct.stock) : "");
    setRating(initialProduct?.rating != null ? String(initialProduct.rating) : "");
    setImage(initialProduct?.image ?? "");
  }, [open, initialProduct]);

  if (!open) return null;

  const title = mode === "edit" ? "Редактирование товара" : "Добавление товара";

  const handleSubmit = (e) => {
    e.preventDefault();

    const trimmedName = name.trim();
    const trimmedCategory = category.trim();
    const trimmedDesc = description.trim();
    const parsedPrice = Number(price);
    const parsedStock = Number(stock);

    if (!trimmedName) return alert("Введите название");
    if (!trimmedCategory) return alert("Введите категорию");
    if (!trimmedDesc) return alert("Введите описание");
    if (!Number.isFinite(parsedPrice) || parsedPrice < 0) return alert("Введите корректную цену");
    if (!Number.isFinite(parsedStock) || parsedStock < 0) return alert("Введите корректное количество");

    // rating и image — опционально
    const payload = {
      id: initialProduct?.id,
      name: trimmedName,
      category: trimmedCategory,
      description: trimmedDesc,
      price: parsedPrice,
      stock: parsedStock,
    };

    if (rating.trim() !== "") payload.rating = Number(rating);
    if (image.trim() !== "") payload.image = image.trim();

    onSubmit(payload);
  };

  return (
    <div className="backdrop" onMouseDown={onClose}>
      <div className="modal" onMouseDown={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
        <div className="modal__header">
          <div className="modal__title">{title}</div>
          <button className="iconBtn" onClick={onClose} aria-label="Закрыть">
            ✕
          </button>
        </div>

        <form className="form" onSubmit={handleSubmit}>
          <label className="label">
            Название
            <input className="input" value={name} onChange={(e) => setName(e.target.value)} />
          </label>

          <label className="label">
            Категория
            <input className="input" value={category} onChange={(e) => setCategory(e.target.value)} />
          </label>

          <label className="label">
            Описание
            <textarea
              className="input"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </label>

          <label className="label">
            Цена (₽)
            <input className="input" value={price} onChange={(e) => setPrice(e.target.value)} inputMode="numeric" />
          </label>

          <label className="label">
            Количество на складе
            <input className="input" value={stock} onChange={(e) => setStock(e.target.value)} inputMode="numeric" />
          </label>

          <label className="label">
            Рейтинг (опционально)
            <input className="input" value={rating} onChange={(e) => setRating(e.target.value)} inputMode="decimal" />
          </label>

          <label className="label">
            Фото URL (опционально)
            <input className="input" value={image} onChange={(e) => setImage(e.target.value)} />
          </label>

          <div className="modal__footer">
            <button type="button" className="btn" onClick={onClose}>
              Отмена
            </button>
            <button type="submit" className="btn btn--primary">
              {mode === "edit" ? "Сохранить" : "Создать"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
