const express = require("express");
const cors = require("cors");
const { nanoid } = require("nanoid");

const app = express();
const port = 3000;

// Разрешаем запросы с фронтенда (React на 3001)
app.use(
  cors({
    origin: "http://localhost:3001",
    methods: ["GET", "POST", "PATCH", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);

// Парсинг JSON
app.use(express.json());

// Логирование запросов
app.use((req, res, next) => {
  res.on("finish", () => {
    console.log(
      `[${new Date().toISOString()}] [${req.method}] ${res.statusCode} ${req.path}`
    );
    if (req.method === "POST" || req.method === "PUT" || req.method === "PATCH") {
      console.log("Body:", req.body);
    }
  });
  next();
});

// ====== ДАННЫЕ (минимум 10 товаров) ======
let products = [
  {
    id: nanoid(6),
    name: "Увлажняющий крем для лица",
    category: "Уход за лицом",
    description: "Лёгкий крем для ежедневного увлажнения, быстро впитывается.",
    price: 590,
    stock: 24,
    rating: 4.7,
    image: "https://picsum.photos/seed/facecream/300/200",
  },
  {
    id: nanoid(6),
    name: "Гель для умывания",
    category: "Уход за лицом",
    description: "Мягко очищает кожу, не стягивает, подходит на каждый день.",
    price: 420,
    stock: 35,
    rating: 4.6,
    image: "https://picsum.photos/seed/cleangel/300/200",
  },
  {
    id: nanoid(6),
    name: "Тоник для лица",
    category: "Уход за лицом",
    description: "Освежает и подготавливает кожу к нанесению крема.",
    price: 390,
    stock: 28,
    rating: 4.4,
    image: "https://picsum.photos/seed/toner/300/200",
  },
  {
    id: nanoid(6),
    name: "Сыворотка с витамином C",
    category: "Сыворотки",
    description: "Помогает выровнять тон кожи и придать сияние.",
    price: 990,
    stock: 15,
    rating: 4.8,
    image: "https://picsum.photos/seed/vitc/300/200",
  },
  {
    id: nanoid(6),
    name: "Сыворотка с гиалуроновой кислотой",
    category: "Сыворотки",
    description: "Интенсивное увлажнение и комфорт в течение дня.",
    price: 920,
    stock: 14,
    rating: 4.7,
    image: "https://picsum.photos/seed/hyaluron/300/200",
  },
  {
    id: nanoid(6),
    name: "Солнцезащитный крем SPF 50",
    category: "Защита от солнца",
    description: "Высокая защита от UVA/UVB, не оставляет белых следов.",
    price: 780,
    stock: 20,
    rating: 4.6,
    image: "https://picsum.photos/seed/spf50/300/200",
  },
  {
    id: nanoid(6),
    name: "Шампунь для ежедневного ухода",
    category: "Уход за волосами",
    description: "Мягкое очищение и свежесть, подходит для частого использования.",
    price: 520,
    stock: 30,
    rating: 4.5,
    image: "https://picsum.photos/seed/shampoo/300/200",
  },
  {
    id: nanoid(6),
    name: "Бальзам-кондиционер",
    category: "Уход за волосами",
    description: "Облегчает расчёсывание, делает волосы мягкими и гладкими.",
    price: 540,
    stock: 22,
    rating: 4.5,
    image: "https://picsum.photos/seed/conditioner/300/200",
  },
  {
    id: nanoid(6),
    name: "Крем для рук питательный",
    category: "Уход за телом",
    description: "Питает и смягчает кожу рук, помогает от сухости.",
    price: 260,
    stock: 40,
    rating: 4.4,
    image: "https://picsum.photos/seed/handcream/300/200",
  },
  {
    id: nanoid(6),
    name: "Гель для душа",
    category: "Уход за телом",
    description: "Деликатно очищает кожу, оставляет ощущение свежести.",
    price: 310,
    stock: 33,
    rating: 4.3,
    image: "https://picsum.photos/seed/showergel/300/200",
  },
  {
    id: nanoid(6),
    name: "Тональный крем",
    category: "Макияж",
    description: "Выравнивает тон, среднее покрытие, комфортная текстура.",
    price: 860,
    stock: 18,
    rating: 4.5,
    image: "https://picsum.photos/seed/foundation/300/200",
  },
  {
    id: nanoid(6),
    name: "Тушь для ресниц",
    category: "Макияж",
    description: "Придаёт объём и разделение, не осыпается в течение дня.",
    price: 650,
    stock: 26,
    rating: 4.6,
    image: "https://picsum.photos/seed/mascara/300/200",
  },
];

// ====== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ======
function findProductOr404(id, res) {
  const product = products.find((p) => p.id === id);
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return null;
  }
  return product;
}

function validateProductPayload(payload, partial = false) {
  // partial=true для PATCH (можно прислать не все поля)
  const errors = [];

  const has = (k) => payload?.[k] !== undefined;

  if (!partial || has("name")) {
    if (typeof payload.name !== "string" || !payload.name.trim()) errors.push("name");
  }
  if (!partial || has("category")) {
    if (typeof payload.category !== "string" || !payload.category.trim()) errors.push("category");
  }
  if (!partial || has("description")) {
    if (typeof payload.description !== "string" || !payload.description.trim())
      errors.push("description");
  }
  if (!partial || has("price")) {
    const price = Number(payload.price);
    if (!Number.isFinite(price) || price < 0) errors.push("price");
  }
  if (!partial || has("stock")) {
    const stock = Number(payload.stock);
    if (!Number.isFinite(stock) || stock < 0) errors.push("stock");
  }

  return errors;
}

// ====== CRUD МАРШРУТЫ ======
// POST /api/products — создание
app.post("/api/products", (req, res) => {
  const errors = validateProductPayload(req.body, false);
  if (errors.length) {
    return res.status(400).json({ error: "Invalid fields", fields: errors });
  }

  const newProduct = {
    id: nanoid(6),
    name: req.body.name.trim(),
    category: req.body.category.trim(),
    description: req.body.description.trim(),
    price: Number(req.body.price),
    stock: Number(req.body.stock),
    rating: req.body.rating !== undefined ? Number(req.body.rating) : undefined,
    image: req.body.image !== undefined ? String(req.body.image) : undefined,
  };

  products.push(newProduct);
  res.status(201).json(newProduct);
});

// GET /api/products — список
app.get("/api/products", (req, res) => {
  res.json(products);
});

// GET /api/products/:id — 1 товар
app.get("/api/products/:id", (req, res) => {
  const product = findProductOr404(req.params.id, res);
  if (!product) return;
  res.json(product);
});

// PATCH /api/products/:id — обновление (частичное)
app.patch("/api/products/:id", (req, res) => {
  const product = findProductOr404(req.params.id, res);
  if (!product) return;

  // Нельзя PATCH без полей
  if (!req.body || Object.keys(req.body).length === 0) {
    return res.status(400).json({ error: "Nothing to update" });
  }

  const errors = validateProductPayload(req.body, true);
  if (errors.length) {
    return res.status(400).json({ error: "Invalid fields", fields: errors });
  }

  if (req.body.name !== undefined) product.name = req.body.name.trim();
  if (req.body.category !== undefined) product.category = req.body.category.trim();
  if (req.body.description !== undefined) product.description = req.body.description.trim();
  if (req.body.price !== undefined) product.price = Number(req.body.price);
  if (req.body.stock !== undefined) product.stock = Number(req.body.stock);
  if (req.body.rating !== undefined) product.rating = Number(req.body.rating);
  if (req.body.image !== undefined) product.image = String(req.body.image);

  res.json(product);
});

// DELETE /api/products/:id — удаление
app.delete("/api/products/:id", (req, res) => {
  const id = req.params.id;
  const exists = products.some((p) => p.id === id);
  if (!exists) return res.status(404).json({ error: "Product not found" });

  products = products.filter((p) => p.id !== id);
  res.status(204).send(); // 204 без тела
});

// 404 для остальных маршрутов
app.use((req, res) => {
  res.status(404).json({ error: "Not found" });
});

// Глобальный обработчик ошибок
app.use((err, req, res, next) => {
  console.error("Unhandled error:", err);
  res.status(500).json({ error: "Internal server error" });
});

// Запуск
app.listen(port, () => {
  console.log(`Backend: http://localhost:${port}`);
});
